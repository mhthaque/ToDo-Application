def speed(distance, time):
    return distance / time


print(speed(300, 5))