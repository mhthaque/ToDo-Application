import shutil

shutil.make_archive("files/python-code", "zip", "..")